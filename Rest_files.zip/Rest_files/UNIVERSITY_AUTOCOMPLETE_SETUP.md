# University Autocomplete Feature - Developer Setup Guide

This guide explains how to set up and populate the university autocomplete data for the forms application.

---

## Overview

The autocomplete feature allows users to select a university from a dynamically filtered list as they type. The data comes from a PostgreSQL database table (`universities`) that is populated by running a seed script against an Excel file.

### What Gets Set Up

- **Database table**: `universities` (name, state, district)
- **Trigram index**: Fast full-text search on university names
- **API endpoint**: `GET /api/autocomplete/universities?q=searchTerm`
- **Frontend**: AutocompleteInput component in form fields

---

## Prerequisites

- Node.js and npm installed
- PostgreSQL installed and running locally (or connection details configured in `server/.env`)
- The Excel file: `final_colege_list.xlsx` (you already have this)

---

## Step 1: Prepare Your Excel File

### Expected Format

The Excel file must have **at least 3 columns** in the first sheet:

| Column 1 | Column 2 | Column 3 |
|----------|----------|----------|
| University Name | State | District |
| Example: "IIT Delhi" | "Delhi" | "New Delhi" |
| Example: "Anna University" | "Tamil Nadu" | "Chennai" |

### Creating the File from `final_colege_list.xlsx`

1. **Open** `final_colege_list.xlsx` in Excel, Google Sheets, or LibreOffice Calc
2. **Ensure your file has exactly 3 columns**:
   - Column A: University/College Name
   - Column B: State/Province
   - Column C: District/Region
3. **Verify** the first row contains **headers** or data (the script will skip the first row as headers)
4. **Save** as `.xlsx` format (Excel 2007+)

> **Important**: If your Excel file has headers in the first row, the seed script will treat them as data and insert them into the database. To avoid this:
> - Either delete the header row before seeding
> - Or modify the seed script to skip the first row (it currently skips row 0, then reads from row 1 onwards)

### Example Structure

```
Row 1: University Name | State | District
Row 2: IIT Delhi | Delhi | New Delhi
Row 3: IIT Bombay | Maharashtra | Mumbai
Row 4: Anna University | Tamil Nadu | Chennai
...
```

---

## Step 2: Place the File in the Correct Location

1. Navigate to your project folder: `f:\Projects\22-2-FORMS\`
2. Go to the `server` subfolder
3. Inside `server`, look for (or create) a `data` folder
4. Place your Excel file there and **rename it to `universities.xlsx`**

**Final path:**
```
f:\Projects\22-2-FORMS\server\data\universities.xlsx
```

### Why This Location?

The seed script (`server/db/seed.js`) looks for the file at:
```javascript
const xlsxPath = path.join(__dirname, '..', 'data', 'universities.xlsx');
```

This resolves to `server/data/universities.xlsx`.

---

## Step 3: Install Dependencies (if needed)

The seed script uses the `xlsx` library to parse Excel files. It's already listed in `server/package.json`.

1. Navigate to the server folder:
   ```bash
   cd f:\Projects\22-2-FORMS\server
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

---

## Step 4: Run Migrations (One-Time Setup)

Before seeding, ensure the database schema is created.

1. From the `server` folder, run:
   ```bash
   npm run migrate
   ```

   This creates tables including `universities` and the trigram index for fast searching.

2. Verify output should look like:
   ```
   Running migrations...
     ✓ pg_trgm extension enabled
     ✓ users table
     ✓ forms table
     ✓ form_versions table
     ✓ form_fields table
     ✓ submissions table
     ✓ submission_values table
     ✓ universities table
     ✓ trigram index on universities.name
     ✓ additional indexes

   ✅ All migrations completed successfully!
   ```

---

## Step 5: Run the Seed Script

Now populate the `universities` table with your data.

1. Ensure you're in the `server` folder:
   ```bash
   cd f:\Projects\22-2-FORMS\server
   ```

2. Run the seed script:
   ```bash
   npm run seed
   ```

3. Expected output:
   ```
   Seeding universities...
     Parsed 5000 rows from Excel
     5000 unique universities after dedup
   
   ✅ Seeded 5000 universities successfully!
   ```

### What Happens

- The script reads your Excel file
- Extracts name, state, and district from columns 1–3
- Removes duplicates (case-insensitive by name)
- Clears the existing `universities` table
- Inserts all unique rows in batches of 100 for efficiency

### If the File is Not Found

If `universities.xlsx` is missing, the script will:
- Log a warning: `⚠ universities.xlsx not found`
- Fall back to seeding **sample development data** (25 Indian universities)

This is useful for initial testing but won't have your full dataset.

---

## Step 6: Verify the Data Was Loaded

### Option A: Via API (requires running server)

1. Start the server:
   ```bash
   npm run dev
   ```

2. Open a browser or use curl to test:
   ```
   http://localhost:5000/api/autocomplete/universities?q=IIT
   ```

3. Should return a JSON array of matching universities:
   ```json
   [
     { "id": 1, "name": "IIT Delhi", "state": "Delhi", "district": "New Delhi" },
     { "id": 2, "name": "IIT Bombay", "state": "Maharashtra", "district": "Mumbai" },
     ...
   ]
   ```

### Option B: Via SQL (direct database query)

Use `psql`, PgAdmin, or any SQL client to connect to your PostgreSQL database:

```sql
-- Count total universities
SELECT COUNT(*) FROM universities;

-- Search for a specific university
SELECT * FROM universities WHERE name ILIKE '%IIT%';

-- View first 10 rows
SELECT * FROM universities LIMIT 10;

-- Check if trigram index is present
SELECT indexname FROM pg_indexes WHERE tablename = 'universities';
```

Expected trigram index name: `idx_universities_name_trgm`

---

## Step 7: Test in the Frontend

1. Start the client:
   ```bash
   cd f:\Projects\22-2-FORMS\client
   npm run dev
   ```

2. Navigate to the **Form Builder** page (admin only)
3. Create or edit a form field
4. Set the field **type** to `autocomplete`
5. Begin typing in the autocomplete field when submitting a form
6. Verify that university names appear as suggestions

---

## Troubleshooting

### Issue: "universities.xlsx not found"

**Solution**: 
- Ensure the file is at `server/data/universities.xlsx`
- Check the file name spelling (case-sensitive on Linux/Mac)
- Verify the `.xlsx` extension (not `.xls` or `.csv`)

### Issue: Seed script completes but no data appears

**Possible causes**:
1. PostgreSQL is not running or connection details are wrong
2. The database doesn't exist
3. Migrations weren't run first

**Solution**:
- Check `server/.env` for database connection settings
- Verify PostgreSQL is running: `psql -U postgres -c "SELECT version();"`
- Run migrations again: `npm run migrate`
- Check logs for error messages

### Issue: API returns no results for valid searches

**Possible causes**:
1. The trigram index wasn't created
2. The data was inserted but the connection is stale
3. The search query is too restrictive

**Solution**:
- Verify index exists: `SELECT * FROM pg_indexes WHERE tablename = 'universities';`
- Rebuild index: `REINDEX INDEX idx_universities_name_trgm;`
- Restart the server after seeding

### Issue: Excel file has unexpected format

**Solution**:
- Ensure only 3 columns are used (A, B, C)
- Remove any extra columns or merged cells
- Verify the data doesn't have leading/trailing spaces
- If your file has headers, manually delete row 1 before seeding

---

## Environment Setup Reference

### Required Environment Variables (`server/.env`)

```
DB_USER=postgres
DB_PASSWORD=yourPassword
DB_HOST=localhost
DB_PORT=5432
DB_NAME=forms_db
JWT_SECRET=your-secret-key
NODE_ENV=development
```

### npm Scripts Available (`server/package.json`)

```bash
npm run migrate    # Create/update database schema
npm run seed       # Populate universities table
npm run dev        # Start server with hot-reload
```

---

## How the Autocomplete Works

1. **User types** in an autocomplete field on the form submission page
2. **Frontend sends** `GET /api/autocomplete/universities?q=searchTerm` to backend
3. **Backend query** uses the trigram index (`idx_universities_name_trgm`) for fast fuzzy matching:
   ```sql
   SELECT * FROM universities 
   WHERE name % $1 
   ORDER BY name <-> $1 
   LIMIT 10
   ```
4. **Results returned** as JSON to frontend
5. **Frontend renders** a dropdown with matching universities

### Why Trigram Index?

PostgreSQL's trigram (3-character) matching allows:
- **Fuzzy search**: "ITT" matches "IIT"
- **Typo tolerance**: "Bombay" matches "Bombai"
- **Fast queries**: Index-backed search on large datasets (1000s of universities)

---

## Backing Up and Exporting Data

### Export Universities to Excel

If you need to extract the universities table back to Excel:

```sql
COPY universities(name, state, district) 
TO '/path/to/export.csv' 
WITH (FORMAT CSV, HEADER);
```

Then convert the CSV to Excel, or use:

```javascript
// Node.js with xlsx library
const XLSX = require('xlsx');
const ws = XLSX.utils.json_to_sheet(jsonData);
const wb = XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb, ws, "Universities");
XLSX.writeFile(wb, "universities.xlsx");
```

---

## Next Steps

- **After setup**: Test the autocomplete in your forms
- **On new PC**: Copy the `universities.xlsx` file and run `npm run seed` again
- **Data updates**: Modify `universities.xlsx` and re-run `npm run seed` to refresh the database
- **Performance**: If you have 10,000+ universities, consider partitioning or caching strategies

---

## Quick Reference

| Step | Command | Expected Output |
|------|---------|-----------------|
| 1. Prepare Excel | (manual) | 3 columns: name, state, district |
| 2. Place file | Move to `server/data/universities.xlsx` | File copied |
| 3. Install deps | `npm install` | Dependencies installed |
| 4. Run migrations | `npm run migrate` | ✅ All migrations completed |
| 5. Seed data | `npm run seed` | ✅ Seeded N universities |
| 6. Verify | `curl localhost:5000/api/autocomplete/universities?q=test` | JSON results |
| 7. Test frontend | Create form field of type `autocomplete` | Suggestions appear on typing |

---

For more information, see:
- [PostgreSQL Full-Text Search](https://www.postgresql.org/docs/current/textsearch.html)
- [xlsx npm package](https://www.npmjs.com/package/xlsx)
- [Trigram Similarity Queries](https://www.postgresql.org/docs/current/pgtrgm.html)
