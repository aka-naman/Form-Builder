# 🚀 Full Docker Project Offline Deployment Guide

This guide explains how to transfer and run your full Docker-based
project (client + server + database) on an offline PC.

------------------------------------------------------------------------

# 🖥️ PART 1 --- On MAIN PC (Online Machine)

## ✅ 1. Stop Project (optional but recommended)

``` powershell
docker-compose down
```

------------------------------------------------------------------------

## ✅ 2. Export Project Images

``` powershell
docker save -o forms-project.tar 22-2-forms-client 22-2-forms-server postgres:14-alpine
```

This creates:

    forms-project.tar

------------------------------------------------------------------------

## ✅ 3. Export Database Volume

``` powershell
docker run --rm `
  -v 22-2-forms_db-data:/volume `
  -v ${PWD}:/backup `
  alpine tar czf /backup/db-volume.tar.gz -C /volume .
```

This creates:

    db-volume.tar.gz

------------------------------------------------------------------------

## ✅ 4. Export Alpine Image (needed for offline restore)

``` powershell
docker save -o alpine.tar alpine
```

------------------------------------------------------------------------

## ✅ 5. Copy These Files to USB / Offline Machine

    forms-project.tar
    db-volume.tar.gz
    alpine.tar
    docker-compose.yml

------------------------------------------------------------------------

# 🖥️ PART 2 --- On OFFLINE PC

⚠️ Docker must already be installed.

------------------------------------------------------------------------

## ✅ 1. Put all files in one folder

Example:

    D:\FormsProject\

Open PowerShell inside that folder.

------------------------------------------------------------------------

## ✅ 2. Load Images

``` powershell
docker load -i forms-project.tar
docker load -i alpine.tar
```

Verify:

``` powershell
docker images
```

You should see:

    22-2-forms-client
    22-2-forms-server
    postgres
    alpine

------------------------------------------------------------------------

## ✅ 3. Create Database Volume

``` powershell
docker volume create 22-2-forms_db-data
```

------------------------------------------------------------------------

## ✅ 4. Restore Database

``` powershell
docker run --rm `
  -v 22-2-forms_db-data:/volume `
  -v ${PWD}:/backup `
  alpine tar xzf /backup/db-volume.tar.gz -C /volume
```

------------------------------------------------------------------------

## ✅ 5. Start Full Project

``` powershell
docker-compose up -d
```

------------------------------------------------------------------------

# 🎉 DONE

Your offline PC now has:

-   Client running
-   Server running
-   Database restored
-   No internet required
-   No rebuilding
-   No npm install

------------------------------------------------------------------------

# 🌐 Open in Browser

    http://localhost

or

    http://localhost:3001

(depending on your port mapping)

------------------------------------------------------------------------

# 🧠 Optional Useful Commands

## Check running containers

``` powershell
docker ps
```

## Stop project

``` powershell
docker-compose down
```

## View logs

``` powershell
docker-compose logs -f
```

------------------------------------------------------------------------

# 🏁 Final Portable Bundle Structure

    FormsProject/
    │
    ├── forms-project.tar
    ├── db-volume.tar.gz
    ├── alpine.tar
    └── docker-compose.yml

This folder = full portable Docker deployment.
