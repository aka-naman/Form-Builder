# Offline Dynamic Form Dashboard with Docker

This guide provides instructions on how to run the Offline Dynamic Form Dashboard application using Docker and Docker Compose. This allows you to run the application in an isolated environment, making it easy to set up on an offline machine.

## Prerequisites

Before you begin, ensure you have the following installed on your system:

- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)

## Getting Started

Follow these steps to get the application up and running:

### 1. Build and Run the Application

Open a terminal in the root of the project directory and run the following command:

```bash
docker-compose up -d --build
```

This command will:

- Build the Docker images for the `client` and `server` services.
- Create and start the containers for the `client`, `server`, and `db` services in detached mode (`-d`).

### 2. Accessing the Application

Once the containers are running, you can access the application in your web browser:

- **Client (Frontend):** [http://localhost:80](http://localhost:80)
- **Server (Backend):** [http://localhost:3000](http://localhost:3000)

### 3. Database

The application uses a PostgreSQL database. The `docker-compose.yml` file is configured to use a Docker volume (`db-data`) to persist the database data. This means that your data will be saved even if you stop and remove the containers.

The database is automatically seeded with initial data when the `server` service starts.

## Stopping the Application

To stop and remove the containers, networks, and volumes created by `docker-compose up`, run the following command in the root of the project directory:

```bash
docker-compose down
```

If you want to stop the containers without removing them, you can use:

```bash
docker-compose stop
```

## Transferring to an Offline PC

To run this project on a PC with no internet connection, you will need to save the built Docker images and transfer them along with the project files.

### 1. Save the Docker Images

After running `docker-compose up -d --build` on a machine with an internet connection, you will have the necessary Docker images locally. You can save them to a `.tar` file:

```bash
docker save -o form-dashboard-images.tar form-dashboard_client form-dashboard_server postgres:14-alpine
```

### 2. Transfer Files

Copy the following to the offline PC:

- The entire project folder.
- The `form-dashboard-images.tar` file.

### 3. Load the Docker Images

On the offline PC, load the Docker images from the `.tar` file:

```bash
docker load -i form-dashboard-images.tar
```

### 4. Run the Application

Now you can run the application using Docker Compose as usual. Since the images are already loaded, Docker Compose will not try to pull them from the internet.

```bash
docker-compose up -d
```