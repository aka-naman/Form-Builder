# Complete Setup Guide: Deploying to a New Windows PC

This guide walks through everything needed to get the exact same prototype running on a new Windows machine.

---

## 🖥️ PART 1: Required Software Installation

Install these in order on your new Windows PC.

### 1. PostgreSQL (Database)
- **Download**: https://www.postgresql.org/download/windows/
- **Version**: 14 or newer recommended
- **Installation Steps**:
  1. Run the installer
  2. Choose default installation path (or customize as needed)
  3. **Important**: Remember the password you set for the `postgres` user (default is `postgres`)
  4. Port: Keep as default `5432`
  5. Locale: Select your region
  6. Complete installation
  7. **Post-install**: PostgreSQL should start automatically. Verify by opening PowerShell and running:
     ```powershell
     psql -U postgres -c "SELECT version();"
     ```

### 2. Node.js (Runtime + npm)
- **Download**: https://nodejs.org/
- **Version**: 18 LTS or newer (current version is fine)
- **Installation Steps**:
  1. Run the `.msi` installer
  2. Accept defaults
  3. **Important**: Check "Add to PATH" (should be checked by default)
  4. Complete installation
  5. Verify in PowerShell:
     ```powershell
     node --version
     npm --version
     ```

### 3. Git (Optional but Recommended)
- **Download**: https://git-scm.com/download/win
- Useful for version control and easy project management
- Installation: Accept defaults, click Next through all screens

### 4. VS Code (Optional but Recommended)
- **Download**: https://code.visualstudio.com/
- Great editor for development
- Installation: Accept defaults

---

## 📋 PART 2: Project Setup

### Step 1: Copy Project Files
Copy the entire `f:\Projects\22-2-FORMS` folder to your new PC.

**On new PC**, place it at a convenient location, e.g.:
```
C:\Users\YourUsername\Projects\22-2-FORMS\
```

Or anywhere you prefer (adjust paths in examples below).

### Step 2: Copy the Universities Data (Optional)
If you want the autocomplete to work with your full college list:

1. Copy `final_colege_list.xlsx` (your Excel file)
2. Paste it in: `server/data/`
3. Rename it to: `universities.xlsx`

**Without this file**, the seed script will use 25 sample Indian universities.

### Step 3: Create .env File
The `.env.example` file is already in the project. You can use the defaults or customize.

**Option A: Use Defaults (Easiest)**
- The project already has `.env.example` with working defaults
- Just make sure PostgreSQL is running locally with these credentials:
  ```
  User: postgres
  Password: postgres (or what you set during installation)
  Database: formbuilder
  ```

**Option B: Create Custom .env**
1. In the root folder (`22-2-FORMS\`), create a file named `.env`
2. Paste this content:
   ```
   PORT=5000
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=formbuilder
   DB_USER=postgres
   DB_PASSWORD=postgres
   JWT_SECRET=form-dashboard-jwt-secret-2026
   ```
3. Save the file

> **Note**: If you used a different password during PostgreSQL installation, replace `postgres` with your actual password.

---

## ⚙️ PART 3: Install Dependencies

Open PowerShell and navigate to your project folder:

```powershell
cd C:\Users\YourUsername\Projects\22-2-FORMS
```

### Install Server Dependencies
```powershell
cd server
npm install
```
Expected output: `added 50+ packages`

### Install Client Dependencies
```powershell
cd ..\client
npm install
```
Expected output: `added 100+ packages`

### Return to Project Root
```powershell
cd ..
```

---

## 🗄️ PART 4: Database Setup

### Step 1: Create Database
Open PowerShell and run:

```powershell
psql -U postgres -c "CREATE DATABASE formbuilder;"
```

If you get an error "database already exists", that's fine (skip to next step).

### Step 2: Run Migrations (Create Schema)

From project root:
```powershell
cd server
npm run migrate
```

**Expected output**:
```
Running migrations...
  ✓ pg_trgm extension enabled
  ✓ users table
  ✓ forms table
  ✓ form_versions table
  ✓ form_fields table
  ✓ submissions table
  ✓ submission_values table
  ✓ universities table
  ✓ trigram index on universities.name
  ✓ additional indexes

✅ All migrations completed successfully!
```

### Step 3: Populate Universities Table

```powershell
npm run seed
```

**Expected output**:
```
Seeding universities...
  Parsed XXXX rows from Excel
  XXXX unique universities after dedup

✅ Seeded XXXX universities successfully!
```

If `universities.xlsx` is not found, it will use 25 sample universities instead.

### Step 4: Verify Database
Open PowerShell and run:
```powershell
psql -U postgres -d formbuilder -c "SELECT COUNT(*) FROM users;"
```

Should return: `(0 rows)`

```powershell
psql -U postgres -d formbuilder -c "SELECT COUNT(*) FROM universities;"
```

Should return the number of universities you seeded.

---

## 🚀 PART 5: Running the Application

### Terminal 1: Start the Server

```powershell
cd C:\Users\YourUsername\Projects\22-2-FORMS\server
npm run dev
```

**Expected output**:
```
Server running on http://localhost:5000
Watching for changes...
```

### Terminal 2: Start the Client (New PowerShell window)

```powershell
cd C:\Users\YourUsername\Projects\22-2-FORMS\client
npm run dev
```

**Expected output**:
```
  VITE v7.3.1  ready in XXX ms

  ➜  Local:   http://localhost:5173/
  ➜  press h to show help
```

### Step 3: Open in Browser

Open your browser and go to:
```
http://localhost:5173
```

You should see the login page.

---

## 🔐 PART 6: Testing the Full Prototype

### Create Admin Account (First Time Only)

1. Click **"Register"** on the login page
2. Create an admin account:
   - Username: `admin`
   - Password: `admin123` (or anything)
3. The first registered user becomes an admin automatically

### Test All Features

#### A. Create a Form
1. Log in as admin
2. Go to **"Form Builder"**
3. Click **"Create New Form"**
4. Add fields:
   - Text field
   - Number/Integer field
   - Autocomplete field (points to universities)
   - Dropdown field
   - Radio buttons, checkboxes, etc.

#### B. Submit a Form
1. Go to **"Submit Form"** (top nav)
2. Select your form
3. Fill in the fields:
   - **Autocomplete**: Start typing university name
   - Should return matching results from `universities` table
4. Submit the form

#### C. View Submissions
1. Go back to **"Form Builder"** (as admin)
2. Click the form
3. Click **"View Submissions"** button
4. See all responses in a table

#### D. Export Data
1. Click **"Export"** button on submissions page
2. Download as `.xlsx` (Excel format)
3. Verify all data is included

#### E. Other Features
- **Duplicate Form**: Click "Duplicate" on any form
- **Delete Form**: Deletes form AND all its responses
- **Lock Form**: Prevents further field edits (auto-locks on first submission)
- **Rename Form**: Click the form name to edit

---

## 📊 PART 7: Verify Everything Works

### Health Check
```powershell
curl http://localhost:5000/api/health
```

Should return:
```json
{"status":"ok","timestamp":"2026-03-02T..."}
```

### Check Universities Autocomplete
```powershell
curl "http://localhost:5000/api/autocomplete/universities?q=IIT"
```

Should return matching universities.

### Database Query Check
```powershell
psql -U postgres -d formbuilder -c "SELECT * FROM forms;"
```

After creating a form, should return your form data.

---

## 🔧 Troubleshooting

### PostgreSQL Connection Error
**Error**: `connect ECONNREFUSED 127.0.0.1:5432`

**Solution**:
1. Verify PostgreSQL is running:
   ```powershell
   psql -U postgres -c "SELECT 1;"
   ```
2. If not, start PostgreSQL from Windows Services:
   - Press `Win + R`, type `services.msc`
   - Find `postgresql-x64-14` (or similar)
   - Right-click, select "Start"

### Wrong Password Error
**Error**: `password authentication failed for user "postgres"`

**Solution**:
1. Use the password you set during PostgreSQL installation
2. Update it in `.env` file:
   ```
   DB_PASSWORD=your-actual-password
   ```

### Port 5000 Already in Use
**Error**: `listening on port 5000 failed`

**Solution**:
1. Change the port in `.env`:
   ```
   PORT=5001
   ```
2. Restart server

### Port 5173 Already in Use (Vite)
**Error**: `port 5173 already in use`

**Solution**:
1. Close any other Vite dev servers
2. Or start on a different port:
   ```powershell
   npm run dev -- --port 5174
   ```

### Universities not appearing in autocomplete
**Issue**: Autocomplete field shows no suggestions

**Solution**:
1. Verify `universities.xlsx` is at `server/data/universities.xlsx`
2. Re-run seed script:
   ```powershell
   npm run seed
   ```
3. Restart server
4. Refresh browser

### Migrations Failed
**Error**: `Migration failed: ...`

**Solution**:
1. Make sure PostgreSQL is running
2. Make sure `formbuilder` database exists:
   ```powershell
   psql -U postgres -c "CREATE DATABASE formbuilder;"
   ```
3. Try again:
   ```powershell
   npm run migrate
   ```

---

## 📝 Quick Reference: Commands to Run

**First-time setup:**
```powershell
# 1. Install dependencies
cd server && npm install
cd ..\client && npm install
cd ..

# 2. Create database
psql -U postgres -c "CREATE DATABASE formbuilder;"

# 3. Run migrations
cd server && npm run migrate

# 4. Seed data
npm run seed

# 5. Start server (Terminal 1)
npm run dev

# 6. Start client (Terminal 2, from client folder)
npm run dev
```

**Subsequent startups (database already exists):**
```powershell
# Terminal 1 - Server
cd C:\...\22-2-FORMS\server
npm run dev

# Terminal 2 - Client
cd C:\...\22-2-FORMS\client
npm run dev

# Then open: http://localhost:5173
```

---

## 💾 Project Structure Reminder

```
22-2-FORMS/
├── .env                          # Environment vars (you create this)
├── .env.example                  # Template (copy if needed)
├── server/
│   ├── package.json              # Dependencies
│   ├── index.js                  # Main server file
│   ├── db/
│   │   ├── migrate.js            # Creates schema
│   │   ├── seed.js               # Populates universities
│   │   └── pool.js               # Database connection
│   ├── routes/
│   │   ├── auth.js               # Login/register
│   │   ├── forms.js              # Form CRUD
│   │   ├── fields.js             # Field management
│   │   ├── submissions.js        # Form submissions
│   │   ├── export.js             # Excel export
│   │   └── autocomplete.js       # University search
│   └── data/
│       └── universities.xlsx     # PUT YOUR COLLEGE LIST HERE
├── client/
│   ├── package.json              # React dependencies
│   ├── index.html                # Entry point
│   ├── main.jsx                  # React app
│   └── src/
│       ├── pages/                # Login, FormBuilder, Submit, etc.
│       ├── components/           # AutocompleteInput, ProtectedRoute, etc.
│       └── contexts/             # Auth, Theme
└── UNIVERSITY_AUTOCOMPLETE_SETUP.md
```

---

## 🎯 Summary

1. **Install**: PostgreSQL, Node.js
2. **Setup**: Copy project, create `.env`
3. **Database**: Create DB, run migrations, run seed
4. **Start**: `npm run dev` in server folder, `npm run dev` in client folder
5. **Test**: http://localhost:5173 → Register → Create forms → Submit → Export

You're ready to go! All features (fields, autocomplete, export, form deletion with cascade cleanup) are included.

---

## 📞 Additional Notes

- **If you forget password for postgres user**, you can reset it using Windows authentication or reinstall PostgreSQL
- **Database backups**: Run `pg_dump -U postgres formbuilder > backup.sql` to backup
- **Restore from backup**: `psql -U postgres formbuilder < backup.sql`
- **Completely reset database**: `dropdb -U postgres formbuilder` then create and run migrations again

Keep this guide handy for future PC migrations! 🚀
